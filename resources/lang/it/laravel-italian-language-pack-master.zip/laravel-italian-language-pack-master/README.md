# laravel-italian-language-pack
Base Italian Language Pack for Laravel 5+

Clone this repo into resources/lang/it to make it working
